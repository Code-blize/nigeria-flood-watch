## University of Leeds / Dartmouth Flood Observatory 2012 Lokoja dataset

**Status:** Acquired and preliminarily inspected; accepted as a supplementary historical validation reference.

**Dataset title:** *Analysis inputs for validation of six global flood models against observed flood events in Nigeria and Mozambique*  
**Principal author:** Mark Bernhofen, University of Leeds.  
**Observed flood source:** Dartmouth Flood Observatory (DFO).  
**Event:** 2012 Nigeria floods; research description reports imagery spanning 15 September–29 October 2012.

**Supplied archives:**
- `Observed_Flooding.zip`
- `Analysis_Areas.zip`
- `Lokoja_GFM_Output.zip`
- `Aggregated_Models.zip`

**Key Lokoja files:**
- `Lokoja_DFO_Observed_Flooding.tif`
- `Lokoja_Analysis_Area` Shapefile components
- Six model outputs for nominal 25-year and 100-year return periods
- Aggregated model-agreement raster

**Observed raster QA:** 1,370 × 1,272 pixels; one unsigned 8-bit band; EPSG:4326; pixel size approximately 0.000833333 degrees; values 0 and 1; no explicit NoData value or separate validity mask detected. README defines 1 as wet and 0 as dry/no data. Thus zero-valued pixels cannot be separated into confirmed dry and unobserved categories from this raster alone.

**Model inventory:** CaMa-Flood, GLOFRIS, ECMWF, JRC, SSBN and CIMA-UNEP. The SSBN file in the nominal 25-year directory is `SSBN_Lokoja_20y.tif`, a 20-year output; preserve this qualification.

**Use:** Historical flood-extent comparison, methodological reproduction and exploratory global flood-model evaluation. Not an operational forecast dataset.

**Limitations:** The nominal 90 m grid is described as resampled from approximately 250 m MODIS observations; the Leeds analysis boundary is not the entire Lokoja LGA; return-period hazard scenarios are not forecasts of the 2012 event; observation dry/no-data ambiguity remains unresolved.

**Report:** See `reports/LEEDS_2012_VALIDATION_REPORT.md`.

**Licence:** The README text supplied for inspection did not state a licence. Verify the official repository licence/terms before redistribution or reuse beyond research permitted by the source.
