## University of Leeds / Dartmouth Flood Observatory 2012 Lokoja dataset

- **Dataset:** *Analysis inputs for validation of six global flood models against observed flood events in Nigeria and Mozambique*.
- **Principal author/institution:** Mark Bernhofen, University of Leeds.
- **Observed flood source:** Dartmouth Flood Observatory (DFO).
- **Files acquired:** `Observed_Flooding.zip`, `Analysis_Areas.zip`, `Lokoja_GFM_Output.zip`, `Aggregated_Models.zip`.
- **Attribution:** Cite the dataset title, Mark Bernhofen and University of Leeds, and acknowledge Dartmouth Flood Observatory as the observed-flood source, following the official repository's citation instructions.
- **Licence status:** **Not verified from the supplied README text.** Check the official University of Leeds repository record and any accompanying licence/terms before redistribution. Do not assume CC BY 4.0 or another open licence without evidence.
- **Reuse limitations:** Preserve source attribution; retain the SSBN 20-year qualification; describe the observed raster as DFO-derived and resampled as documented; do not represent modelled return-period outputs as observations or forecasts.
- **Project location:** Preserve original archives under `data/raw/leeds/`; derived analysis products under `data/processed/`; report under `reports/LEEDS_2012_VALIDATION_REPORT.md`.
