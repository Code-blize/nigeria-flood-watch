# University of Leeds / Dartmouth Flood Observatory 2012 Lokoja Dataset: Validation Report

**Project:** NigeriaFloodWatch  
**Study area:** Lokoja, Kogi State, Nigeria  
**Dataset:** *Analysis inputs for validation of six global flood models against observed flood events in Nigeria and Mozambique*  
**Principal author:** Mark Bernhofen, University of Leeds  
**Observed flood source:** Dartmouth Flood Observatory (DFO)  
**Event:** 2012 Nigeria floods  
**Status:** Preliminary reproducibility and data-quality assessment  
**Prepared:** 20 November 2026

---

## 1. Purpose

This report records the inspection and exploratory comparison of the University of Leeds dataset for Lokoja. The dataset provides an observed 2012 flood raster, study-area boundaries, six global flood model outputs for nominal 25-year and 100-year return periods, and an aggregated model-agreement raster.

The purpose of the work is to assess whether these materials can support historical flood-extent comparison and reproducible model-evaluation experiments for NigeriaFloodWatch.

This dataset is a historical validation reference. It is not an operational forecast dataset and does not, by itself, establish forecast skill.

## 2. Source and contents

The supplied README describes the dataset as inputs used to validate six global flood models against observed events in Nigeria and Mozambique.

The supplied archives inspected for this assessment were:

- `Observed_Flooding.zip`
- `Analysis_Areas.zip`
- `Lokoja_GFM_Output.zip`
- `Aggregated_Models.zip`

The observed flood archive contains GeoTIFF rasters for Lokoja, Idah and Chemba. The analysis-area archive contains Shapefiles for the three study regions. The Lokoja model archive contains 12 classified GeoTIFFs: six nominal 25-year outputs and six 100-year outputs. The aggregated archive contains the model-agreement raster(s).

The six models named in the README are:

- CaMa-Flood
- GLOFRIS
- ECMWF (European Centre for Medium-Range Weather Forecasts)
- JRC (Joint Research Centre)
- SSBN
- CIMA-UNEP

**Return-period qualification:** the file named `SSBN_Lokoja_20y.tif` represents a 20-year return period, not 25 years. It must not be described as a 25-year output.

The README states that the observed 2012 flood data were obtained from the Dartmouth Flood Observatory and that the GeoTIFFs are in WGS84. It describes a nominal pixel resolution of 1/1200 decimal degrees (approximately 90 m).

## 3. Observed Lokoja flood raster

File: `Lokoja_DFO_Observed_Flooding.tif`

Inspected properties:

| Property | Result |
|---|---|
| Raster dimensions | 1,370 columns × 1,272 rows |
| Bands | 1 |
| Data type | Unsigned 8-bit integer |
| Coordinate reference system | EPSG:4326 (WGS84) |
| Pixel size | Approximately 0.000833333 degrees |
| Stored values | 0 and 1 |
| Explicit NoData metadata | Not defined in the inspected GeoTIFF |
| Wet-classified pixels over full raster | 158,984 |
| Zero-valued pixels over full raster | 1,583,656 |

The supplied README defines the Lokoja and Idah coding as `1 = wet` and `0 = dry/no data`. The GeoTIFF does not contain a separate NoData value or validity mask that distinguishes genuinely dry pixels from unobserved pixels.

**Interpretation limitation:** zero-valued pixels cannot be confidently interpreted as confirmed dry land. Metrics that classify every zero as a verified dry observation are conditional on the binary-mask convention and may be affected by unobserved areas.

The research description associated with the dataset reports that the Nigerian event observation was assembled from 45 days of imagery spanning 15 September to 29 October 2012, and that the original approximately 250 m MODIS observations were resampled to approximately 90 m for comparison. The finer output grid must not be mistaken for new 90 m observational detail. Confirm the exact event-processing details against the original publication and its supplementary methods before formal publication.

## 4. Study-area boundary and comparison domain

The University of Leeds Lokoja analysis-area polygon was used for the exploratory raster comparison.

The comparison domain contains 490,596 raster pixels under the pixel-centre inclusion rule used in the analysis. This is the Leeds analysis area, not the entire Lokoja Local Government Area and not the separate provisional Copernicus local analysis extent.

Do not describe results calculated within this boundary as results for the whole Lokoja LGA.

## 5. Model outputs and aggregated agreement

The aggregated raster records the number of the six global flood models that classify each pixel as wet. The observed and aggregated Lokoja rasters were inspected as having matching dimensions, geographic extent and nominal pixel resolution. The direct comparison used their common grid.

The full-raster aggregated raster inspection previously recorded the following counts:

| Agreement value | Interpretation | Full-raster pixel count |
|---:|---|---:|
| 0 | No model classifies wet / dry or no data | 1,495,330 |
| 1 | One model classifies wet | 42,118 |
| 2 | Two models classify wet | 36,060 |
| 3 | Three models classify wet | 31,460 |
| 4 | Four models classify wet | 29,533 |
| 5 | Five models classify wet | 43,450 |
| 6 | All six models classify wet | 64,689 |

These counts are for the full raster, not restricted to the Leeds analysis boundary. A separate within-boundary calculation was reported as 490,596 pixels total, with 247,230 pixels having at least one model indicating wet, 169,132 having at least three models indicating wet, and 64,673 having all six models indicating wet.

## 6. Exploratory individual-model comparison

The following results were reported from the exploratory comparison against the observed 2012 raster within the Leeds analysis boundary. Model rasters with differing grids were aligned to the observed raster using nearest-neighbour resampling.

Metrics:

- **Critical Success Index (CSI):** hits / (hits + false alarms + misses).
- **Hit Rate (HR):** hits / (hits + misses).
- **Bias:** (modelled wet area / observed wet area) − 1.

Here, hits are pixels classified wet by both observation and model; false alarms are model-wet pixels not classified wet in the observation; misses are observed-wet pixels not classified wet by the model.

### Nominal 25-year outputs

| Model | CSI | HR | Bias |
|---|---:|---:|---:|
| JRC | 0.777 | 0.919 | +0.054 |
| CIMA-UNEP | 0.681 | 0.742 | -0.096 |
| CaMa-Flood | 0.679 | 0.760 | -0.068 |
| ECMWF | 0.666 | 0.996 | +0.246 |
| SSBN (20-year) | 0.640 | 0.742 | -0.057 |
| GLOFRIS | 0.432 | 0.495 | -0.240 |

### 100-year outputs

| Model | CSI | HR | Bias |
|---|---:|---:|---:|
| JRC | 0.781 | 0.947 | +0.082 |
| CaMa-Flood | 0.759 | 0.886 | +0.029 |
| SSBN | 0.725 | 0.892 | +0.064 |
| CIMA-UNEP | 0.722 | 0.800 | -0.051 |
| ECMWF | 0.655 | 0.997 | +0.260 |
| GLOFRIS | 0.519 | 0.603 | -0.145 |

These figures are exploratory and conditional on treating zero-valued observed pixels as non-wet. They must not be represented as definitive validation statistics until the original observation-validity treatment, raster alignment and calculations have been independently rerun and documented in executable code.

A comparison with the published paper was reported to show close agreement in the approximate Lokoja CSI values. This is a useful reproduction check, but agreement with a published result is not independent proof that the underlying model outputs are accurate.

## 7. Exploratory aggregated-model comparison

The aggregated raster was evaluated at thresholds requiring at least 1 through 6 models to classify a pixel as wet.

| Minimum agreeing models | CSI | HR | Bias |
|---:|---:|---:|---:|
| 1 of 6 | 0.641 | 0.998 | +0.555 |
| 2 of 6 | 0.733 | 0.969 | +0.290 |
| 3 of 6 | 0.748 | 0.883 | +0.064 |
| 4 of 6 | 0.706 | 0.772 | -0.134 |
| 5 of 6 | 0.608 | 0.635 | -0.320 |
| 6 of 6 | 0.382 | 0.389 | -0.593 |

Within this exploratory comparison, the threshold of at least three agreeing models produced the highest CSI (0.748). This is a result for this dataset, event, analysis boundary and classification procedure; it is not a universally optimal consensus threshold.

The six models should not be assumed statistically independent. Agreement among models is not equivalent to independent observational confirmation.

## 8. Scientific limitations

1. **Observation validity:** the observed raster's zero values combine dry and no-data classes in the README. The supplied raster does not expose a separate validity mask.
2. **Observation resolution:** the approximately 90 m grid is a resampled representation of coarser MODIS observations; it does not create finer observational detail.
3. **Study-area scope:** results apply to the University of Leeds Lokoja analysis area, not automatically to the entire Lokoja LGA.
4. **Different product types:** the observed event footprint and return-period hazard scenarios are not equivalent products.
5. **Return-period mismatch:** SSBN's nominal 25-year folder contains a 20-year file.
6. **Model dependence:** the six global models may share input data, assumptions or structures; consensus should not be interpreted as independent validation.
7. **No forecast-skill claim:** these comparisons do not evaluate forecasts issued before the event and cannot establish operational forecast accuracy.

## 9. Recommended use in NigeriaFloodWatch

Accept the University of Leeds / DFO 2012 Lokoja dataset as a **historical validation and methodological reference**, subject to the limitations above.

Appropriate uses:

- historical flood-extent comparison;
- testing raster alignment and evaluation workflows;
- reproducing published global flood-model comparisons;
- exploratory analysis of model agreement thresholds;
- development of quality-control procedures for binary flood masks.

Do not use it alone to:

- claim operational forecast accuracy;
- infer current flood risk;
- treat every zero-valued observation pixel as confirmed dry;
- claim that the global models predicted the 2012 event;
- train a model without first assessing label validity, temporal relevance and spatial resolution.

## 10. Required follow-up work

Before treating the reported metrics as final:

1. Re-run the evaluation from the original archives using a version-controlled script.
2. Record exact raster transforms, bounds, pixel sizes, resampling choices and boundary rasterization rule for every input.
3. Determine whether the DFO source archive or original authors can provide an observation-validity mask distinguishing dry from unobserved pixels.
4. Recalculate metrics under clearly stated valid-observation assumptions.
5. Save per-model confusion counts and metrics as machine-readable CSV files.
6. Compare the Leeds analysis boundary with the Lokoja LGA and Copernicus local analysis extent, without treating them as interchangeable.
7. Preserve original archives unchanged under `data/raw/leeds/`; place derived rasters and tables under `data/processed/` and reports under `reports/`.

## 11. Provenance and attribution

Dataset title: *Analysis inputs for validation of six global flood models against observed flood events in Nigeria and Mozambique*.

Principal author: Mark Bernhofen, University of Leeds, School of Civil Engineering.

Observed flood source: Dartmouth Flood Observatory.

The supplied README identifies the dataset and its contents but does not state a licence in the text provided for this assessment. **Do not assume a Creative Commons licence without checking the repository's official licence or terms.** Record the verified licence and attribution requirements in `DATA_SOURCE_LICENCE_REGISTER.md` after checking the official repository record.

---

**Status:** Suitable as a supplementary historical validation reference; exploratory metrics recorded; formal validation remains conditional on resolving the observed raster's dry/no-data ambiguity and reproducing the workflow in code.
