## Historical flood validation: University of Leeds / DFO 2012 Lokoja dataset

### Purpose
The University of Leeds dataset provides a DFO-derived observed 2012 Lokoja flood raster, an analysis-area boundary, six global flood model outputs for nominal 25-year and 100-year return periods, and an aggregated model-agreement raster. It is used as a supplementary historical validation and methodological reference.

### Evaluation domain
The exploratory comparison used the University of Leeds Lokoja analysis-area polygon. A pixel-centre inclusion rule produced a comparison domain of 490,596 pixels. This is not the full Lokoja LGA and must not be described as such.

### Metrics
For binary wet/non-wet comparison:
- Critical Success Index (CSI) = hits / (hits + false alarms + misses).
- Hit Rate (HR) = hits / (hits + misses).
- Bias = (modelled wet area / observed wet area) − 1.

Hits are wet in both observed and modelled rasters; false alarms are model-wet but observation-non-wet; misses are observation-wet but model-non-wet.

### Raster alignment
The observed raster was used as the reference grid. Model rasters with different grids were aligned using nearest-neighbour resampling to preserve categorical classes. Record the exact transform, bounds, resolution, resampling method and boundary rasterization rule in the executable analysis.

### Exploratory results
The exploratory results are recorded in `reports/LEEDS_2012_VALIDATION_REPORT.md`. They include individual model metrics and aggregated agreement thresholds from one to six models. The reported CSI values closely matched approximate values in the published Lokoja comparison figure; this is a reproduction check, not independent proof of model accuracy.

### Critical limitations
The observed raster README defines 1 as wet and 0 as dry/no data. The GeoTIFF has no separate NoData metadata or validity mask. Consequently, metrics that treat all zeros as confirmed dry are conditional and must not be presented as definitive until observation validity is clarified. The approximately 90 m grid is a resampled representation of coarser MODIS observations and does not add observational detail. Return-period hazard scenarios are not forecasts issued before the 2012 event. SSBN's file in the nominal 25-year folder is a 20-year output.

### Interpretation
These experiments assess spatial agreement with a historical event under stated assumptions. They do not establish operational forecast skill, current flood risk, or that the global models predicted the 2012 event. Model agreement is not necessarily independent because model inputs and assumptions may be shared.

### Required reproducibility work
Re-run from the original archives using a version-controlled script; save per-model confusion counts and metrics; document all raster alignment and boundary rules; investigate an observation-validity mask from DFO or the dataset authors; and retain a separate flag for dry versus unknown wherever supported by source data.
